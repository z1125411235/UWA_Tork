﻿public enum DrawLevel {
	None,
	OnSelected,
	Always
}