﻿namespace Adrenak.Tork {
	public class VehicleInput {
		public float steering;
		public float acceleration;
		public float brake;
	}
}